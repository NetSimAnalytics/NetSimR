# Package index

## Shiny tools

Applications that run the package’s models without writing code.

- [`run_shiny_simulator()`](https://netsimanalytics.github.io/NetSimR/reference/run_shiny_simulator.md)
  : A function to run the shiny simulator application
- [`run_shiny_distribution_fitting_tool()`](https://netsimanalytics.github.io/NetSimR/reference/run_shiny_distribution_fitting_tool.md)
  : Run the distribution fitting application
- [`run_shiny_glm_fitting_tool()`](https://netsimanalytics.github.io/NetSimR/reference/run_shiny_glm_fitting_tool.md)
  : Run the generalised linear model fitting application
- [`run_shiny_reserving_tool()`](https://netsimanalytics.github.io/NetSimR/reference/run_shiny_reserving_tool.md)
  : Run the claims reserving application
- [`run_shiny_reinsurance_pricing_tool()`](https://netsimanalytics.github.io/NetSimR/reference/run_shiny_reinsurance_pricing_tool.md)
  : Run the reinsurance pricing application
- [`run_shiny_portfolio_tool()`](https://netsimanalytics.github.io/NetSimR/reference/run_shiny_portfolio_tool.md)
  : Run the portfolio capital application

## Claims simulation and reinsurance

Frequency-severity simulation with Pareto tails, caps and layers, and
portfolios of lines joined by a copula.

- [`simulate_claims()`](https://netsimanalytics.github.io/NetSimR/reference/simulate_claims.md)
  : Simulate claims with a frequency-severity model
- [`simulate_function()`](https://netsimanalytics.github.io/NetSimR/reference/simulate_function.md)
  : Simulate insurance claims with reinsurance structures
- [`simulate_portfolio()`](https://netsimanalytics.github.io/NetSimR/reference/simulate_portfolio.md)
  : Simulate a portfolio of dependent lines
- [`apply_deductible_limit()`](https://netsimanalytics.github.io/NetSimR/reference/apply_deductible_limit.md)
  : Apply a deductible and limit to claims
- [`reinstatement_premium()`](https://netsimanalytics.github.io/NetSimR/reference/reinstatement_premium.md)
  : Reinstatement premiums of an excess of loss layer
- [`compare_reinsurance()`](https://netsimanalytics.github.io/NetSimR/reference/compare_reinsurance.md)
  : Compare reinsurance programmes

## Claims reserving

Chain ladder with Mack’s standard errors, methods with premiums, the
bootstrap, the one-year view, the Munich chain ladder, Clark’s growth
curves, inflation and actual vs expected.

- [`chain_ladder()`](https://netsimanalytics.github.io/NetSimR/reference/chain_ladder.md)
  : Chain ladder reserves with Mack's standard errors
- [`bornhuetter_ferguson()`](https://netsimanalytics.github.io/NetSimR/reference/bornhuetter_ferguson.md)
  : Bornhuetter-Ferguson and Benktander reserves
- [`cape_cod()`](https://netsimanalytics.github.io/NetSimR/reference/cape_cod.md)
  : Cape Cod reserves
- [`bootstrap_chain_ladder()`](https://netsimanalytics.github.io/NetSimR/reference/bootstrap_chain_ladder.md)
  : Bootstrap of the chain ladder reserves
- [`merz_wuthrich()`](https://netsimanalytics.github.io/NetSimR/reference/merz_wuthrich.md)
  : The one-year view of the reserves: Merz and Wuthrich's claims
  development result
- [`munich_chain_ladder()`](https://netsimanalytics.github.io/NetSimR/reference/munich_chain_ladder.md)
  : Munich chain ladder of paid and incurred claims
- [`actual_vs_expected()`](https://netsimanalytics.github.io/NetSimR/reference/actual_vs_expected.md)
  : Actual against expected development
- [`clark_growth()`](https://netsimanalytics.github.io/NetSimR/reference/clark_growth.md)
  : Clark's growth curve reserves
- [`inflation_adjusted_chain_ladder()`](https://netsimanalytics.github.io/NetSimR/reference/inflation_adjusted_chain_ladder.md)
  : Chain ladder for claims inflation
- [`as_triangle()`](https://netsimanalytics.github.io/NetSimR/reference/as_triangle.md)
  : Build a claims triangle from a table

## IFRS 17 and Solvency II

Discounted reserves, the risk adjustment, and the standard formula’s
non-life premium and reserve risk.

- [`discount_reserves()`](https://netsimanalytics.github.io/NetSimR/reference/discount_reserves.md)
  : Discounted reserves from the chain ladder's payment pattern
- [`risk_adjustment()`](https://netsimanalytics.github.io/NetSimR/reference/risk_adjustment.md)
  : Risk adjustment for non-financial risk
- [`sii_premium_reserve_risk()`](https://netsimanalytics.github.io/NetSimR/reference/sii_premium_reserve_risk.md)
  : Solvency II standard formula: non-life premium and reserve risk
- [`sii_nonlife_segments`](https://netsimanalytics.github.io/NetSimR/reference/sii_nonlife_segments.md)
  [`sii_nonlife_correlation`](https://netsimanalytics.github.io/NetSimR/reference/sii_nonlife_segments.md)
  : The Solvency II standard formula's non-life segments

## Excess of loss pricing

Burning cost, Pareto rating, exposure rating with MBBEFD curves or a
claim size distribution, and the technical premium.

- [`burning_cost()`](https://netsimanalytics.github.io/NetSimR/reference/burning_cost.md)
  : Burning cost of an excess of loss layer
- [`pareto_rating()`](https://netsimanalytics.github.io/NetSimR/reference/pareto_rating.md)
  : Pareto rating of an excess of loss layer
- [`property_exposure_rating()`](https://netsimanalytics.github.io/NetSimR/reference/property_exposure_rating.md)
  [`casualty_exposure_rating()`](https://netsimanalytics.github.io/NetSimR/reference/property_exposure_rating.md)
  : Exposure rating of property and casualty excess of loss layers
- [`mbbefd_curve()`](https://netsimanalytics.github.io/NetSimR/reference/mbbefd_curve.md)
  [`swiss_re_parameters()`](https://netsimanalytics.github.io/NetSimR/reference/mbbefd_curve.md)
  [`swiss_re_curve()`](https://netsimanalytics.github.io/NetSimR/reference/mbbefd_curve.md)
  : MBBEFD exposure curves
- [`technical_premium()`](https://netsimanalytics.github.io/NetSimR/reference/technical_premium.md)
  : Technical premium of an excess of loss layer
- [`credibility_weight()`](https://netsimanalytics.github.io/NetSimR/reference/credibility_weight.md)
  : Credibility of the loss experience

## Pricing models and rate reviews

A Tweedie family for generalised linear models of the loss cost,
on-level premiums, the indicated rate change and Buhlmann-Straub
credibility.

- [`tweedie_family()`](https://netsimanalytics.github.io/NetSimR/reference/tweedie_family.md)
  : Tweedie family for generalised linear models
- [`on_level_premium()`](https://netsimanalytics.github.io/NetSimR/reference/on_level_premium.md)
  : Premiums at today's rates: the parallelogram method
- [`indicated_rate_change()`](https://netsimanalytics.github.io/NetSimR/reference/indicated_rate_change.md)
  : The indicated rate change: the loss ratio method
- [`buhlmann_straub()`](https://netsimanalytics.github.io/NetSimR/reference/buhlmann_straub.md)
  : Buhlmann-Straub credibility

## Capped means

- [`GammaCappedMean()`](https://netsimanalytics.github.io/NetSimR/reference/GammaCappedMean.md)
  [`gamma_capped_mean()`](https://netsimanalytics.github.io/NetSimR/reference/GammaCappedMean.md)
  : Gamma capped mean
- [`LNormCappedMean()`](https://netsimanalytics.github.io/NetSimR/reference/LNormCappedMean.md)
  [`lnorm_capped_mean()`](https://netsimanalytics.github.io/NetSimR/reference/LNormCappedMean.md)
  : Lognormal capped mean
- [`ParetoCappedMean()`](https://netsimanalytics.github.io/NetSimR/reference/ParetoCappedMean.md)
  [`pareto_capped_mean()`](https://netsimanalytics.github.io/NetSimR/reference/ParetoCappedMean.md)
  : Pareto capped mean
- [`ParetoCappedMeanCalc()`](https://netsimanalytics.github.io/NetSimR/reference/ParetoCappedMeanCalc.md)
  [`pareto_capped_mean_calc()`](https://netsimanalytics.github.io/NetSimR/reference/ParetoCappedMeanCalc.md)
  : Pareto capped mean intermediary calculation
- [`SlicedGammaParetoCappedMean()`](https://netsimanalytics.github.io/NetSimR/reference/SlicedGammaParetoCappedMean.md)
  [`sliced_gamma_pareto_capped_mean()`](https://netsimanalytics.github.io/NetSimR/reference/SlicedGammaParetoCappedMean.md)
  : Sliced Gamma Pareto capped mean
- [`SlicedLNormParetoCappedMean()`](https://netsimanalytics.github.io/NetSimR/reference/SlicedLNormParetoCappedMean.md)
  [`sliced_lnorm_pareto_capped_mean()`](https://netsimanalytics.github.io/NetSimR/reference/SlicedLNormParetoCappedMean.md)
  : Sliced LogNormal Pareto capped mean

## Exposure curves and increased limit factors

- [`ExposureCurveGamma()`](https://netsimanalytics.github.io/NetSimR/reference/ExposureCurveGamma.md)
  [`exposure_curve_gamma()`](https://netsimanalytics.github.io/NetSimR/reference/ExposureCurveGamma.md)
  : Exposure Curve from a Gamma severity distribution
- [`ExposureCurveLNorm()`](https://netsimanalytics.github.io/NetSimR/reference/ExposureCurveLNorm.md)
  [`exposure_curve_lnorm()`](https://netsimanalytics.github.io/NetSimR/reference/ExposureCurveLNorm.md)
  : Exposure Curve from a LogNormal severity distribution
- [`ExposureCurvePareto()`](https://netsimanalytics.github.io/NetSimR/reference/ExposureCurvePareto.md)
  [`exposure_curve_pareto()`](https://netsimanalytics.github.io/NetSimR/reference/ExposureCurvePareto.md)
  : Exposure Curve from a Pareto severity distribution
- [`ExposureCurveSlicedGammaPareto()`](https://netsimanalytics.github.io/NetSimR/reference/ExposureCurveSlicedGammaPareto.md)
  [`exposure_curve_sliced_gamma_pareto()`](https://netsimanalytics.github.io/NetSimR/reference/ExposureCurveSlicedGammaPareto.md)
  : Exposure Curve from a Sliced Gamma Pareto severity distribution
- [`ExposureCurveSlicedLNormPareto()`](https://netsimanalytics.github.io/NetSimR/reference/ExposureCurveSlicedLNormPareto.md)
  [`exposure_curve_sliced_lnorm_pareto()`](https://netsimanalytics.github.io/NetSimR/reference/ExposureCurveSlicedLNormPareto.md)
  : Exposure Curve from a Sliced LogNormal Pareto severity distribution
- [`ILFGamma()`](https://netsimanalytics.github.io/NetSimR/reference/ILFGamma.md)
  [`ilf_gamma()`](https://netsimanalytics.github.io/NetSimR/reference/ILFGamma.md)
  : Increased Limit Factor Curve from a Gamma severity distribution
- [`ILFLNorm()`](https://netsimanalytics.github.io/NetSimR/reference/ILFLNorm.md)
  [`ilf_lnorm()`](https://netsimanalytics.github.io/NetSimR/reference/ILFLNorm.md)
  : Increased Limit Factor Curve from a LogNormal severity distribution
- [`ILFPareto()`](https://netsimanalytics.github.io/NetSimR/reference/ILFPareto.md)
  [`ilf_pareto()`](https://netsimanalytics.github.io/NetSimR/reference/ILFPareto.md)
  : Increased Limit Factor Curve from a Pareto severity distribution
- [`ILFSlicedGammaPareto()`](https://netsimanalytics.github.io/NetSimR/reference/ILFSlicedGammaPareto.md)
  [`ilf_sliced_gamma_pareto()`](https://netsimanalytics.github.io/NetSimR/reference/ILFSlicedGammaPareto.md)
  : Increased Limit Factor Curve from a Sliced Gamma Pareto severity
  distribution
- [`ILFSlicedLNormPareto()`](https://netsimanalytics.github.io/NetSimR/reference/ILFSlicedLNormPareto.md)
  [`ilf_sliced_lnorm_pareto()`](https://netsimanalytics.github.io/NetSimR/reference/ILFSlicedLNormPareto.md)
  : Increased Limit Factor Curve from a Sliced LogNormal Pareto severity
  distribution

## Sliced distributions

LogNormal or Gamma bodies with a Pareto tail.

- [`SlicedGammaParetoMean()`](https://netsimanalytics.github.io/NetSimR/reference/SlicedGammaParetoMean.md)
  [`sliced_gamma_pareto_mean()`](https://netsimanalytics.github.io/NetSimR/reference/SlicedGammaParetoMean.md)
  : Sliced Gamma Pareto mean
- [`SlicedLNormParetoMean()`](https://netsimanalytics.github.io/NetSimR/reference/SlicedLNormParetoMean.md)
  [`sliced_lnorm_pareto_mean()`](https://netsimanalytics.github.io/NetSimR/reference/SlicedLNormParetoMean.md)
  : Sliced LogNormal Pareto mean
- [`dSlicedGammaPareto()`](https://netsimanalytics.github.io/NetSimR/reference/dSlicedGammaPareto.md)
  [`dsliced_gamma_pareto()`](https://netsimanalytics.github.io/NetSimR/reference/dSlicedGammaPareto.md)
  : The probability density function (pdf) of a Sliced Gamma Pareto
  severity distribution
- [`pSlicedGammaPareto()`](https://netsimanalytics.github.io/NetSimR/reference/pSlicedGammaPareto.md)
  [`psliced_gamma_pareto()`](https://netsimanalytics.github.io/NetSimR/reference/pSlicedGammaPareto.md)
  : The cumulative distribution function (cdf) of a Sliced Gamma-Pareto
  severity distribution
- [`qSlicedGammaPareto()`](https://netsimanalytics.github.io/NetSimR/reference/qSlicedGammaPareto.md)
  [`qsliced_gamma_pareto()`](https://netsimanalytics.github.io/NetSimR/reference/qSlicedGammaPareto.md)
  : The inverse cumulative distribution function of a Sliced Gamma
  Pareto severity distribution
- [`dSlicedLNormPareto()`](https://netsimanalytics.github.io/NetSimR/reference/dSlicedLNormPareto.md)
  [`dsliced_lnorm_pareto()`](https://netsimanalytics.github.io/NetSimR/reference/dSlicedLNormPareto.md)
  : The probability density function (pdf) of a Sliced LogNormal Pareto
  severity distribution
- [`pSlicedLNormPareto()`](https://netsimanalytics.github.io/NetSimR/reference/pSlicedLNormPareto.md)
  [`psliced_lnorm_pareto()`](https://netsimanalytics.github.io/NetSimR/reference/pSlicedLNormPareto.md)
  : The cumulative distribution function (cdf) of a Sliced LogNormal
  Pareto severity distribution
- [`qSlicedLNormPareto()`](https://netsimanalytics.github.io/NetSimR/reference/qSlicedLNormPareto.md)
  [`qsliced_lnorm_pareto()`](https://netsimanalytics.github.io/NetSimR/reference/qSlicedLNormPareto.md)
  : The inverse cumulative distribution function of a Sliced LogNormal
  Pareto severity distribution

## Pure IBNR and unearned premium

- [`PureIBNRGamma()`](https://netsimanalytics.github.io/NetSimR/reference/PureIBNRGamma.md)
  [`pure_ibnr_gamma()`](https://netsimanalytics.github.io/NetSimR/reference/PureIBNRGamma.md)
  : Pure IBNR exposure from a Gamma reporting delay distribution
- [`PureIBNRLNorm()`](https://netsimanalytics.github.io/NetSimR/reference/PureIBNRLNorm.md)
  [`pure_ibnr_lnorm()`](https://netsimanalytics.github.io/NetSimR/reference/PureIBNRLNorm.md)
  : Pure IBNR exposure from a LogNormal reporting delay distribution

## Special functions

- [`IGamma()`](https://netsimanalytics.github.io/NetSimR/reference/IGamma.md)
  [`upper_incomplete_gamma()`](https://netsimanalytics.github.io/NetSimR/reference/IGamma.md)
  : Upper incomplete gamma function
- [`erf()`](https://netsimanalytics.github.io/NetSimR/reference/erf.md)
  : Error function

## Data sets

- [`raa_triangle`](https://netsimanalytics.github.io/NetSimR/reference/raa_triangle.md)
  : RAA triangle of incurred claims
- [`taylor_ashe_triangle`](https://netsimanalytics.github.io/NetSimR/reference/taylor_ashe_triangle.md)
  : Taylor and Ashe triangle of paid claims
- [`quarg_mack_paid`](https://netsimanalytics.github.io/NetSimR/reference/quarg_mack.md)
  [`quarg_mack_incurred`](https://netsimanalytics.github.io/NetSimR/reference/quarg_mack.md)
  : Paid and incurred triangles of the Munich chain ladder paper
- [`simulated_motor_claims`](https://netsimanalytics.github.io/NetSimR/reference/simulated_motor_claims.md)
  : Simulated motor claims with premiums
- [`xl_large_losses`](https://netsimanalytics.github.io/NetSimR/reference/xl_large_losses.md)
  : Simulated large losses of an excess of loss treaty
- [`xl_premium`](https://netsimanalytics.github.io/NetSimR/reference/xl_premium.md)
  : Subject premiums of an excess of loss treaty
- [`xl_property_profile`](https://netsimanalytics.github.io/NetSimR/reference/xl_property_profile.md)
  : Risk profile of a property portfolio
- [`xl_casualty_profile`](https://netsimanalytics.github.io/NetSimR/reference/xl_casualty_profile.md)
  : Risk profile of a casualty portfolio
- [`motor_policies`](https://netsimanalytics.github.io/NetSimR/reference/motor_policies.md)
  : Simulated motor policies
- [`liability_claims`](https://netsimanalytics.github.io/NetSimR/reference/liability_claims.md)
  : Simulated liability claims at their policy limits
