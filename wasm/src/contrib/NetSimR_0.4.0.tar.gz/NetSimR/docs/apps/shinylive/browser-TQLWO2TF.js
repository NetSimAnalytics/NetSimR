// Shinylive 0.10.16
// Copyright 2026 Posit, PBC
import{c as t}from"./chunk-AWRXMKOZ.js";var o=t((r,e)=>{e.exports=function(){throw new Error("ws does not work in the browser. Browser clients must use the native WebSocket object")}});export default o();
