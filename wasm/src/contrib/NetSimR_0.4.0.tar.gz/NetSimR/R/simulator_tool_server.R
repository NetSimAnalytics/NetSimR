#' Server function for the Shiny Simulator application
#'
#' Builds the dynamic inputs of the claims simulator, runs the simulations when asked and
#' serves the results tabs, the downloads and the saving and loading of settings; it is
#' the server that \code{\link{run_shiny_simulator}} pairs with \code{shiny_simulator_ui}.
#'
#' @param input Input for the server function.
#' @param output Output for the server function.
#' @param session Session for the server function.
#' @return Called by shiny for its side effects, the outputs and observers of a
#'   session; the value is not used.
#' @keywords internal
#' @import shiny
#' @import methods
#' @import stats
#' @import utils
shiny_simulator_server <- function(input, output, session) {
  # the parts of the server, each a function of its own (below), in the order of what they use of
  # each other: `tool` holds what the earlier parts define
  tool <- list()
  tool <- c(tool, sim_server_processing(input, output, session, tool))
  tool <- c(tool, sim_server_remembered(input, output, session, tool))
  tool <- c(tool, sim_server_distributions(input, output, session, tool))
  tool <- c(tool, sim_server_slices(input, output, session, tool))
  tool <- c(tool, sim_server_reinsurance(input, output, session, tool))
  tool <- c(tool, sim_server_settings(input, output, session, tool))
  tool <- c(tool, sim_server_run(input, output, session, tool))
  tool <- c(tool, sim_server_downloads(input, output, session, tool))
  sim_server_output_options(output)
  # every reactive of the parts under its own name here too, where tests of the server find it
  list2env(tool, environment())
  invisible(NULL)
}

# The processing part of the simulator's server: its outputs and observers. `tool` holds what the
# earlier parts define; the part returns what it defines, for the parts after it.
sim_server_processing <- function(input, output, session, tool) {
  #the parallel workers of the session (a socket cluster of the parallel package): started
  #once, when Parallel is chosen or an Auto run first finds them worth starting, so that
  #every later run reuses the warm workers
  #instead of paying the start-up cost each time; shut down when the session ends, or when
  #a worker fails, and the next run starts fresh ones
  workers <- NULL
  stop_parallel_workers <- function() {
    if (is.null(workers)) return(invisible(FALSE))
    cluster <- workers
    workers <<- NULL
    netsimr_stop_workers(cluster)
    invisible(TRUE)
  }
  session$onSessionEnded(stop_parallel_workers)

  start_parallel_workers <- function() {
    if (!is.null(workers)) return(invisible(FALSE))
    showNotification("Starting parallel workers...", type = "message", duration = 3, id = "parallel_workers_notice")
    workers <<- netsimr_start_workers()
    invisible(TRUE)
  }
  #the processing chosen: "auto" (the default), "single" or "parallel"; in a web browser no
  #worker processes can be started, so everything runs in the session
  #the workers running now, NULL when none are
  current_workers <- function() workers
  processing_choice <- function() {
    if (netsimr_in_browser()) return("single")
    choice <- input$processing
    if (is.character(choice) && length(choice) == 1 && choice %in% c("auto", "single", "parallel")) choice else "auto"
  }
  observeEvent(input$processing, {
    if (identical(processing_choice(), "parallel")) {
      tryCatch(start_parallel_workers(), error = function(e) {
        showNotification(paste("The parallel workers could not be started:", conditionMessage(e)), type = "error", duration = NULL)
      })
    }
  })

  list(workers = workers, stop_parallel_workers = stop_parallel_workers,
       start_parallel_workers = start_parallel_workers, current_workers = current_workers,
       processing_choice = processing_choice)
}

# The remembered values part of the simulator's server: its outputs and observers. `tool` holds what the
# earlier parts define; the part returns what it defines, for the parts after it.
sim_server_remembered <- function(input, output, session, tool) {
  #the last value of each input that the server rebuilds (distribution parameters, the seed,
  #the cap and the layer fields): a rebuilt field starts from it, so switching an option away
  #and back (Poisson -> Binomial -> Poisson), or between options that share a field (a limited
  #and an unlimited layer both have a deductible), keeps what was typed (values saved with the
  #Save settings button are unaffected). Loaded settings and examples put their values here
  #too, so a field built after a load starts from the loaded value. The Normal keeps its own
  #parameter ids, so its values do not carry over to the Log-Normal
  typed <- reactiveValues()
  remembered_ids <- unique(c(
    unlist(lapply(freq_dist_options, function(x) x@paramIDs), use.names = FALSE)
    ,unlist(lapply(sev_dist_options, function(x) x@paramIDs), use.names = FALSE)
    ,"seedValue", "sev_cap_amount"
    ,"reinsurance_structure_eel_deductible_amount", "reinsurance_structure_eel_limit_amount"
    ,"reinsuranceStructureLimitedReinstatements", "reinsuranceStructureReinstatementLimit"
    ,"reinsurance_structure_eel_premium", "reinsurance_structure_eel_reinstatement_rate_pct"
    ,"reinsurance_structure_al_deductible_amount", "reinsurance_structure_al_limit_amount"
  ))
  lapply(remembered_ids, function(id) {
    #a cleared field (NA) is remembered too; a field that is not on the page (NULL) is not
    observeEvent(input[[id]], typed[[id]] <- input[[id]])
  })
  last_typed <- function(id, default = NULL) {
    value <- isolate(typed[[id]])
    if (is.null(value)) default else value
  }

  list(typed = typed, remembered_ids = remembered_ids, last_typed = last_typed)
}

# The distributions part of the simulator's server: its outputs and observers. `tool` holds what the
# earlier parts define; the part returns what it defines, for the parts after it.
sim_server_distributions <- function(input, output, session, tool) {
  last_typed <- tool$last_typed

  #seed input
  output$seed_value <- renderUI({
    if (input$seedSetBinary) {
      #set.seed() takes any whole number in the integer range
      numericInput('seedValue', 'Seed value', value = last_typed("seedValue", 1), min = -.Machine$integer.max,
                   max = .Machine$integer.max, step = 1)
    }
  })

  #implied mean and standard deviation of the chosen distributions, updated as parameters are typed
  distribution_inputs <- function(options, id) {
    lapply(options[[id]]@paramIDs, function(x) input[[x]])
  }
  freq_moments <- reactive({
    req(input$freqDistr)
    distribution_moments(freq_dist_options, input$freqDistr, distribution_inputs(freq_dist_options, input$freqDistr))
  })
  sev_moments <- reactive({
    req(input$sevDistr)
    distribution_moments(
      sev_dist_options, input$sevDistr, distribution_inputs(sev_dist_options, input$sevDistr)
      ,truncate_at_zero = isTRUE(input$sevTruncateAtZero) && input$sevDistr == "Normal"
    )
  })
  format_moment <- function(x) {
    if (is.infinite(x)) return("infinite")
    #very large values (e.g. a mean of 1e308) in the report's format rather than 300 digits
    if (abs(x) >= 1e15) return(formatC(x, format = "e", digits = 3))
    format(signif(x, 4), big.mark = ",", scientific = FALSE, trim = TRUE)
  }
  render_implied_moments <- function(moments) {
    if (anyNA(moments)) {
      return(div(class = "sim-implied sim-implied-empty", "Enter the parameters to see the implied mean"))
    }
    div(
      class = "sim-implied"
      ,"Implied mean ", tags$strong(format_moment(moments[["mean"]]))
      ,paste0(" ", intToUtf8(183), " "), "SD ", tags$strong(format_moment(moments[["sd"]]))
    )
  }
  output$freq_implied_moments <- renderUI(render_implied_moments(freq_moments()))
  output$sev_implied_moments <- renderUI(render_implied_moments(sev_moments()))

  #expected gross claims per period, E[N] * E[X]; hidden while either figure is unavailable
  output$expected_gross_claims <- renderUI({
    expected <- freq_moments()[["mean"]] * sev_moments()[["mean"]]
    if (is.na(expected)) return(NULL)
    div(
      class = "sim-expected"
      ,div(class = "sim-expected-label", "Expected gross claims per period")
      ,div(class = "sim-expected-value", format_moment(expected))
      ,div(class = "sim-expected-note", "before tail adjustments and reinsurance")
    )
  })

  #help function to render freq/sev parameters: the slot'th input shown, in the
  #distribution's display order (the Pareto shows x_m before alpha); amounts show
  #thousands separators
  render_UI_param <- function(slot, object){
    param_id <- param_display_positions(object)[slot]
    if (is.na(object@paramIDs[param_id])) return(NULL)
    id <- object@paramIDs[param_id]
    if (isTRUE(object@param_amounts[param_id])) {
      return(netsimr_amount_input(id, object@param_labels[param_id], value = last_typed(id),
                              min = object@param_min_values[param_id], max = object@param_max_values[param_id]))
    }
    numericInput(
      inputId = id
      ,label = object@param_labels[param_id]
      ,min = object@param_min_values[param_id]
      ,max = object@param_max_values[param_id]
      ,step = if (isTRUE(object@param_whole_numbers[param_id])) 1 else NA
      ,value = last_typed(id)
    )
  }

  #render frequency parameters
  lapply(freq_dist_parameter_placeholders$param_number, function(i) {
    output[[paste0("freq_param_", i)]] <- renderUI({
      render_UI_param(slot=i, object=freq_dist_options[[input$freqDistr]])
    })
  })

  #render severity parameters
  lapply(sev_dist_parameter_placeholders$param_number, function(i) {
    output[[paste0("sev_param_", i)]] <- renderUI({
      render_UI_param(slot=i, object=sev_dist_options[[input$sevDistr]])
    })
  })

  list(distribution_inputs = distribution_inputs, freq_moments = freq_moments, sev_moments = sev_moments,
       format_moment = format_moment, render_implied_moments = render_implied_moments,
       render_UI_param = render_UI_param)
}

# The pareto slices part of the simulator's server: its outputs and observers. `tool` holds what the
# earlier parts define; the part returns what it defines, for the parts after it.
sim_server_slices <- function(input, output, session, tool) {
  #Pareto slices: the hidden input pareto_slice_times holds the number of slices and decides
  #which slice rows the UI shows; the add and remove buttons change it, and saved settings
  #restore it like any other number
  pareto_slice_count <- reactive({
    n <- suppressWarnings(as.numeric(input$pareto_slice_times))
    if (length(n) != 1 || is.na(n)) 0 else min(max(round(n), 0), max_number_of_pareto_slices)
  })
  #slice j has its alpha in slice_pareto_param_(2j - 1) and its threshold in slice_pareto_param_(2j)
  slice_input_id <- function(slice, part) paste0("slice_pareto_param_", 2 * slice - (part == "alpha"))

  #the number of slices is the server's (slices()): the add and remove buttons and loaded
  #settings change it and send it to the hidden input, which reports each number back a little
  #later. The numbers sent are queued until they come back, in the order sent, so that a click
  #before then (two quick clicks) builds on the number sent, and the report of an older number
  #does not undo a newer one; a number the input reports that was not sent (typed, as tests do)
  #is taken as it is
  slices <- reactiveVal(0)
  slice_counts_sent <- numeric(0)
  current_slice_count <- function() isolate(slices())
  set_slice_count <- function(n) {
    #the number the input shows once the numbers already sent arrive; sending it again would not
    #come back, as the input reports only a change
    showing <- if (length(slice_counts_sent) > 0) slice_counts_sent[length(slice_counts_sent)] else isolate(pareto_slice_count())
    slices(n)
    if (n != showing) {
      slice_counts_sent <<- c(slice_counts_sent, n)
      updateNumericInput(session, "pareto_slice_times", value = n)
    }
  }
  observeEvent(input$pareto_slice_times, {
    n <- pareto_slice_count()
    if (length(slice_counts_sent) > 0 && n == slice_counts_sent[1]) {
      slice_counts_sent <<- slice_counts_sent[-1]
    } else {
      slice_counts_sent <<- numeric(0)
      slices(n)
    }
  })

  #clicks are counted by how far the button's value moved, so clicks that reach the server
  #together (the value jumps by two) add a slice each
  add_clicks_seen <- 0
  observeEvent(input$add_pareto_slice, {
    clicks <- as.numeric(input$add_pareto_slice)
    added <- clicks - add_clicks_seen
    add_clicks_seen <<- clicks
    n <- current_slice_count()
    if (added > 0 && n < max_number_of_pareto_slices) set_slice_count(min(n + added, max_number_of_pareto_slices))
  })

  lapply(seq_len(max_number_of_pareto_slices), function(i) {
    observeEvent(input[[paste0("remove_pareto_slice_", i)]], {
      n <- current_slice_count()
      if (i > n) return()
      #move the later slices up one place and clear the last one, so no values are lost
      for (j in seq_len(n - i) + i - 1) {
        for (part in c("alpha", "threshold")) {
          value <- input[[slice_input_id(j + 1, part)]]
          updateNumericInput(session, slice_input_id(j, part), value = if (is.null(value)) NA else value)
        }
      }
      for (part in c("alpha", "threshold")) updateNumericInput(session, slice_input_id(n, part), value = NA)
      set_slice_count(n - 1)
    }, ignoreInit = TRUE)
  })

  list(pareto_slice_count = pareto_slice_count, slice_input_id = slice_input_id, slices = slices,
       slice_counts_sent = slice_counts_sent, current_slice_count = current_slice_count,
       set_slice_count = set_slice_count, add_clicks_seen = add_clicks_seen)
}

# The cap and reinsurance part of the simulator's server: its outputs and observers. `tool` holds what the
# earlier parts define; the part returns what it defines, for the parts after it.
sim_server_reinsurance <- function(input, output, session, tool) {
  last_typed <- tool$last_typed

  #render severity cap amount
  output$sev_cap_amount_ui <- renderUI({
    if (input$sevCapBinary) {
      netsimr_amount_input('sev_cap_amount', 'Severity Cap Amount', value = last_typed('sev_cap_amount'), min = 0)
    }
  })

  #reinsurance structure EEL inputs
  output$reinsuranceStructureDeductibleEEL <- renderUI({
    if (input$reinsuranceStructureEEL %in% c('Unlimited Layer', 'Exclude Layer', 'Limited Layer')) {
      netsimr_amount_input('reinsurance_structure_eel_deductible_amount', 'EEL Deductible Amount',
                       value = last_typed('reinsurance_structure_eel_deductible_amount'), min = 0)
    }
  })

  output$reinsuranceStructureLimitEEL <- renderUI({
    if (input$reinsuranceStructureEEL %in% c('Limited Layer', 'Exclude Layer')) {
      netsimr_amount_input('reinsurance_structure_eel_limit_amount', 'EEL Limit Amount',
                       value = last_typed('reinsurance_structure_eel_limit_amount'), min = 0)
    }
  })

  output$reinsuranceStructureLimitedReinstatements_ui <- renderUI({
    if (input$reinsuranceStructureEEL %in% c('Limited Layer')) {
      checkboxInput('reinsuranceStructureLimitedReinstatements', 'Limited reinstatements',
                    value = isTRUE(last_typed('reinsuranceStructureLimitedReinstatements', FALSE)))
    }
  })

  output$reinsuranceStructureReinstatementLimit_ui <- renderUI({
    #(req() leaves the fields out while limited reinstatements are off)
    req(input$reinsuranceStructureLimitedReinstatements)
    if (input$reinsuranceStructureEEL %in% c('Limited Layer')) {
      tagList(
        numericInput('reinsuranceStructureReinstatementLimit', 'Number of Reinstatements',
                     value = last_typed('reinsuranceStructureReinstatementLimit'), min = 0),
        #an optional upfront premium prices the reinstatements used
        div(
          class = "param-grid",
          netsimr_amount_input('reinsurance_structure_eel_premium', 'Upfront premium (optional)',
                           value = last_typed('reinsurance_structure_eel_premium'), min = 0),
          numericInput('reinsurance_structure_eel_reinstatement_rate_pct', 'Reinstatement rate (% of upfront)',
                       value = last_typed('reinsurance_structure_eel_reinstatement_rate_pct', 100), min = 0)
        ),
        helpText("With an upfront premium, the results price the reinstatements used, pro rata to the amount reinstated.")
      )
    }
  })

  #reinsurance structure AL inputs
  output$reinsuranceStructureDeductibleAL <- renderUI({
    if (input$reinsuranceStructureAL %in% c('Unlimited Layer', 'Exclude Layer', 'Limited Layer')) {
      netsimr_amount_input('reinsurance_structure_al_deductible_amount', 'AL Deductible Amount',
                       value = last_typed('reinsurance_structure_al_deductible_amount'), min = 0)
    }
  })

  output$reinsuranceStructureLimitAL <- renderUI({
    if (input$reinsuranceStructureAL %in% c('Limited Layer', 'Exclude Layer')) {
      netsimr_amount_input('reinsurance_structure_al_limit_amount', 'AL Limit Amount',
                       value = last_typed('reinsurance_structure_al_limit_amount'), min = 0)
    }
  })

  list()
}

# The settings files part of the simulator's server: its outputs and observers. `tool` holds what the
# earlier parts define; the part returns what it defines, for the parts after it.
sim_server_settings <- function(input, output, session, tool) {
  remembered_ids <- tool$remembered_ids
  set_slice_count <- tool$set_slice_count
  typed <- tool$typed

  #save and load of the simulator settings, with built-in examples; loaded values of the
  #rebuilt fields are remembered at once, so a field built after the load starts from them,
  #and the loaded number of slices replaces any number sent by a click just before the load
  sim_settings_io_server(
    input, output, session
    ,remember = function(id, value) {
      if (id %in% remembered_ids) typed[[id]] <- value
    }
    ,apply = function(id, kind, value) {
      if (identical(id, "pareto_slice_times")) set_slice_count(value) else sim_settings_apply_update(session, id, kind, value)
    }
  )

  list()
}

# The run part of the simulator's server: its outputs and observers. `tool` holds what the
# earlier parts define; the part returns what it defines, for the parts after it.
sim_server_run <- function(input, output, session, tool) {
  current_workers <- tool$current_workers
  freq_moments <- tool$freq_moments
  processing_choice <- tool$processing_choice
  slice_input_id <- tool$slice_input_id
  slices <- tool$slices
  start_parallel_workers <- tool$start_parallel_workers
  stop_parallel_workers <- tool$stop_parallel_workers

  #the latest successful run (id, settings, data, finished), for the results tabs and the downloads
  last_run <- reactiveVal(NULL)
  run_counter <- 0L

  #in-app Report and Compare tabs (R/simulator_tool_tabs.R); both follow last_run
  sim_report_tab_server("report", last_run, reactive(input$sim_navbar))
  sim_compare_tab_server("compare", last_run)

  #the settings of a run, from the inputs
  collect_run_settings <- function() {
    slice_count <- slices()
    #sapply on purpose: it gives a numeric vector when every field is filled in, and a list
    #when a field is still empty (NULL), which find_missing_simulation_settings() reports by name
    list(
      freq_params = unname(sapply(
        freq_dist_options[[input$freqDistr]]@paramIDs
        ,function(x) input[[x]]
      ))
      ,sev_params = unname(sapply(
        sev_dist_options[[input$sevDistr]]@paramIDs
        ,function(y) input[[y]]
      ))
      ,numOfSimulations = input$numberOfSimulations
      ,seedSetBinary = input$seedSetBinary
      ,seedValue = input$seedValue
      ,freqDistr = input$freqDistr
      ,sevDistr = input$sevDistr
      ,paretoSlice = slice_count > 0
      ,pareto_slice_times = if (slice_count > 0) slice_count
      ,slice_pareto_alphas = if (slice_count > 0) unname(sapply(
        seq_len(slice_count)
        ,function(y) input[[slice_input_id(y, "alpha")]]
      ))
      ,slice_pareto_x_ms = if (slice_count > 0) unname(sapply(
        seq_len(slice_count)
        ,function(y) input[[slice_input_id(y, "threshold")]]
      ))
      ,sevCapBinary = input$sevCapBinary
      ,sev_cap_amount = input$sev_cap_amount
      ,reinsuranceStructureEEL = input$reinsuranceStructureEEL
      ,reinsurance_structure_eel_deductible_amount = input$reinsurance_structure_eel_deductible_amount
      ,reinsurance_structure_eel_limit_amount = input$reinsurance_structure_eel_limit_amount
      ,reinsuranceStructureAL = input$reinsuranceStructureAL
      ,reinsurance_structure_al_deductible_amount = input$reinsurance_structure_al_deductible_amount
      ,reinsurance_structure_al_limit_amount = input$reinsurance_structure_al_limit_amount
      ,multiprocessing = switch(processing_choice(), auto = "auto", single = FALSE, parallel = TRUE)
      ,sevTruncateAtZero = isTRUE(input$sevTruncateAtZero) && input$sevDistr == "Normal"
      ,reinsuranceStructureLimitedReinstatements = input$reinsuranceStructureLimitedReinstatements
      ,reinsuranceStructureReinstatementLimit = input$reinsuranceStructureReinstatementLimit
      #the premium is optional: an empty field (NA) is no premium; the rate is typed in %
      ,reinsurance_structure_eel_premium = input$reinsurance_structure_eel_premium
      ,reinsurance_structure_eel_reinstatement_rates = input$reinsurance_structure_eel_reinstatement_rate_pct / 100
      #the largest claim of each period, for the report's occurrence exceedance (OEP); left out of
      #runs of more than 20 million claims, where drawing every claim would take many seconds
      ,largest_claims = sim_wants_largest_claims(tryCatch(freq_moments()[["mean"]], error = function(e) NA),
                                                 input$numberOfSimulations)
    )
  }

  #the message that lists the settings to fix before a run. While it shows, it follows the
  #fields: a field filled in leaves the list, and the message goes once nothing is left, rather
  #than listing fields already fixed until it times out. It shows for 10 seconds from its last
  #change; after that, changing a field does not bring it back
  missing_notice <- reactiveValues(listed = NULL, until = NULL)
  show_missing_notice <- function(missing) {
    showNotification(
      tags$div(
        tags$strong("Please fix these settings before running:"),
        tags$ul(lapply(missing, tags$li))
      ),
      type = "error",
      duration = 10,
      id = "missing_settings_notice"
    )
    missing_notice$listed <- missing
    missing_notice$until <- Sys.time() + 10
  }
  hide_missing_notice <- function() {
    removeNotification("missing_settings_notice")
    missing_notice$listed <- NULL
    missing_notice$until <- NULL
  }
  observe({
    listed <- missing_notice$listed
    until <- missing_notice$until
    req(listed, until)
    missing <- tryCatch(find_missing_simulation_settings(collect_run_settings()), error = function(e) listed)
    isolate({
      if (Sys.time() > until) {
        missing_notice$listed <- NULL
        missing_notice$until <- NULL
      } else if (length(missing) == 0) {
        hide_missing_notice()
      } else if (!identical(missing, listed)) {
        show_missing_notice(missing)
      }
    })
  })

  #run simulation button: the browser disables the button and shows "Running..." on click;
  #the message sent at the end re-enables it
  observeEvent(input$RunSimulations,{
    on.exit(session$sendCustomMessage("netsimr-run-finished", TRUE), add = TRUE)

    #collect the settings for this run
    new_settings <- collect_run_settings()

    #stop before running and tell the user which fields are empty
    missing_settings <- find_missing_simulation_settings(new_settings)
    if (length(missing_settings) > 0) {
      show_missing_notice(missing_settings)
      return(NULL)
    }
    hide_missing_notice()

    on.exit(gc(), add = TRUE)

    #run simmulations
    results <- tryCatch(
      {
        if (isTRUE(new_settings$multiprocessing)) {
          #workers may have been shut down after a worker failed; make sure they are up
          start_parallel_workers()
        }
        #Auto starts the workers only for a run that is faster with them, and keeps them;
        #a run on the workers shows the number of workers, a run in the session its chunks
        run_workers <- if (!is.null(current_workers())) current_workers() else function() {
          start_parallel_workers()
          current_workers()
        }
        shiny::withProgress(message = "Simulating", value = 0, {
          do.call(simulate_function, c(new_settings, list(
            workers = run_workers,
            progress = function(value, detail) shiny::setProgress(value, detail = detail)
          )))
        })
      }, error = function(cond) {
        #an error raised by the simulation itself (a parameter out of range, an overflow) is
        #caught on its worker, which stays healthy and warm for the next run; a worker error
        #means a worker died or its connection was lost, so the workers are shut down and the
        #next run starts fresh ones
        if (inherits(cond, "netsimr_worker_error")) stop_parallel_workers()
        showNotification(
          paste("Error:", conditionMessage(cond)),
          type = "error",
          duration = NULL
        )
        message("Simulation failed: ", conditionMessage(cond))
        NULL
      }
    )

    #a failed run keeps the previous results, so the downloads and the results tabs still agree
    if (is.null(results)) return(NULL)

    #record the run for the downloads and the results tabs, with how it ran: on how many
    #workers, whatever the choice was
    new_settings$multiprocessing <- isTRUE(netsimr_last_run$parallel)
    new_settings$workers <- if (new_settings$multiprocessing) netsimr_last_run$workers
    run_counter <<- run_counter + 1L
    last_run(list(
      id = run_counter
      ,settings = new_settings
      ,data = results
      ,finished = Sys.time()
    ))
    #a run started from the foot of the settings on a narrow screen then opens the Report tab
    session$sendCustomMessage("netsimr-run-succeeded", run_counter)
  })

  list(last_run = last_run, run_counter = run_counter, collect_run_settings = collect_run_settings,
       missing_notice = missing_notice, show_missing_notice = show_missing_notice,
       hide_missing_notice = hide_missing_notice)
}

# The downloads part of the simulator's server: its outputs and observers. `tool` holds what the
# earlier parts define; the part returns what it defines, for the parts after it.
sim_server_downloads <- function(input, output, session, tool) {
  last_run <- tool$last_run

  #the browser shows "Preparing report..." on click; the report handler re-enables the button
  output$downloadReportButton <- renderUI({
    req(last_run())
    downloadButton('downloadReportHandler', 'Report', icon = icon("file-lines"), class = "btn-outline-primary")
  })

  #download data button
  output$DownloadDataHandler <- downloadHandler(
    filename = function() { paste0('Simulation_data', '.csv') },
    content = function(file) {
      showNotification(
        "Preparing data file, save dialog will appear shortly...",
        type = "message",
        duration = 2
      )
      #the data are unrounded and write.csv keeps 15 significant digits; only the screen rounds
      write.csv(last_run()$data, file, row.names = FALSE)
    }
  )

  output$downloadDataButton <- renderUI({
    req(last_run())
    downloadButton('DownloadDataHandler', 'CSV data', icon = icon("file-csv"), class = "btn-outline-primary")
  })

  #download report button
  output$downloadReportHandler <- downloadHandler(
    filename = "simulation_report.html",
    content = function(file) {
      on.exit(session$sendCustomMessage("netsimr-report-finished", TRUE), add = TRUE)

      showNotification(
        "Preparing report, save dialog will appear shortly...",
        type = "message",
        duration = 3
      )

      run <- last_run()
      shiny::withProgress(message = "Preparing report", value = 0.3, detail = "Building report", {
        #the report is assembled in R (see write_simulation_report), so no pandoc is needed
        tryCatch(
          write_simulation_report(
            file = file,
            settings = run$settings,
            results = run$data
          ),
          error = function(cond) {
            #without this the download just fails, with the reason only in the R console
            showNotification(
              paste("The report could not be created:", conditionMessage(cond)),
              type = "error",
              duration = NULL
            )
            stop(cond)
          }
        )

        incProgress(1, detail = "Done")
      })
    }
  )

  list()
}

# Keeps the outputs that the settings build rendering while the page hides them, once every
# part of the server has defined its outputs.
sim_server_output_options <- function(output) {
  #keep dynamic outputs rendering even while their empty containers are collapsed by the UI styles
  dynamic_outputs <- c(
    freq_dist_parameter_placeholders$param_id
    ,sev_dist_parameter_placeholders$param_id
    ,"reinsuranceStructureDeductibleEEL", "reinsuranceStructureLimitEEL"
    ,"reinsuranceStructureDeductibleAL", "reinsuranceStructureLimitAL"
    ,"downloadDataButton", "downloadReportButton"
    ,"freq_implied_moments", "sev_implied_moments", "expected_gross_claims"
  )
  for (output_name in dynamic_outputs) {
    outputOptions(output, output_name, suspendWhenHidden = FALSE)
  }
  invisible(NULL)
}
