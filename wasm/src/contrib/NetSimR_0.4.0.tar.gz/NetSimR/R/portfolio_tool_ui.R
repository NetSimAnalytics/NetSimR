#' User interface of the Shiny portfolio capital tool
#'
#' @description The page of the portfolio capital application: a welcome tab, the
#'   lines, their dependence and the capital, with the settings beside the results;
#'   \code{\link{run_shiny_portfolio_tool}} pairs it with \code{portfolio_tool_Server}.
#'   Like the package's other applications, the page is built each time the
#'   application starts, not when the package is installed.
#' @param request The request of the browser, passed by shiny; not used.
#' @return The user interface of the application, a bslib navbar page.
#' @keywords internal
portfolio_tool_UI <- function(request) {
  dot <- paste0(" ", intToUtf8(183), " ")
  bslib::page_navbar(
    title = div(
      class = "sim-brand",
      div(class = "sim-brand-mark", icon("cubes")),
      div(
        class = "sim-brand-text",
        tags$span(class = "sim-brand-title", "NetCapital"),
        tags$span(class = "sim-brand-subtitle", "Portfolio capital by NetSimR")
      )
    ),
    window_title = "NetCapital \u2013 Portfolio Capital Tool",
    id = "pfo_navbar",
    selected = "welcome",
    fillable = FALSE,

    navbar_options = bslib::navbar_options(bg = "#052e16", theme = "dark", underline = FALSE),

    theme = netsimr_bs_theme("#15803d"),

    header = tagList(
      netsimr_tool_head("netsimr-portfolio-theme", netsimr_css(c("tools", "analysis", "portfolio"))),
      #tells the server which theme is showing, so the charts are drawn in matching colours
      tags$script(HTML(netsimr_theme_input_js("app_theme"))),
      netsimr_busy_indicators("#86efac", "#15803d")
    ),

    # ---------------------------------------------------------------- Welcome
    bslib::nav_panel(
      title = "Welcome",
      value = "welcome",
      icon = icon("house"),

      bslib::layout_columns(
        col_widths = bslib::breakpoints(sm = 12, lg = c(8, 4)),
        div(
          class = "sim-hero",
          div(class = "sim-hero-eyebrow", "NetCapital"),
          div(class = "sim-hero-title", "Portfolio Capital Tool"),
          p(
            class = "sim-hero-text",
            "Simulate the annual losses of several lines of business, join them with a Gaussian or t copula, and ",
            "measure the portfolio's value at risk and tail value at risk, the diversification between the lines ",
            "and each line's share of the capital."
          ),
          tags$button(
            type = "button",
            class = "btn btn-light",
            onclick = "document.querySelector('.navbar a[data-value=\"lines\"]').click();",
            icon("layer-group"), " Set the lines"
          )
        ),
        bslib::card(
          netsimr_card_header("route", "How it works"),
          bslib::card_body(
            tags$ol(
              class = "sim-steps",
              tags$li(div(div(class = "sim-step-title", "Set the lines"),
                          div(class = "sim-step-text", "A frequency and severity for each, or upload simulated losses."))),
              tags$li(div(div(class = "sim-step-title", "Set the dependence"),
                          div(class = "sim-step-text", "A Gaussian or t copula, with a correlation for each pair."))),
              tags$li(div(div(class = "sim-step-title", "Measure the capital"),
                          div(class = "sim-step-text", "VaR, TVaR, diversification and each line's capital."))),
              tags$li(div(div(class = "sim-step-title", "Share it"),
                          div(class = "sim-step-text", "A report, the summary and the simulated losses.")))
            )
          )
        )
      ),

      bslib::layout_columns(
        col_widths = bslib::breakpoints(sm = 12, md = c(4, 4, 4)),
        div(class = "sim-stat",
            div(class = "sim-stat-label", icon("layer-group"), "Lines"),
            div(class = "sim-stat-value", paste(c("Poisson", "Negative Binomial", "LogNormal", "Gamma", "Pareto", "Uploads"),
                                                collapse = dot))),
        div(class = "sim-stat",
            div(class = "sim-stat-label", icon("link"), "Dependence"),
            div(class = "sim-stat-value", paste(c("Gaussian copula", "t copula", "Correlation matrix"), collapse = dot))),
        div(class = "sim-stat",
            div(class = "sim-stat-label", icon("scale-balanced"), "Capital"),
            div(class = "sim-stat-value", paste(c("VaR", "TVaR", "Diversification", "Co-TVaR allocation"), collapse = dot)))
      ),

      netsimr_about_card("Portfolio capital tool", tagList(
        "The function behind the tool, ", tags$code("simulate_portfolio()"), ", can also be used from R."))
    ),

    # ------------------------------------------------------------------ Lines
    bslib::nav_panel(
      title = "Lines",
      value = "lines",
      icon = icon("layer-group"),

      netsimr_page_intro("Lines", "The lines of business and the annual losses of each."),

      netsimr_layout(
        div(class = "pfo-settings-stack",
          netsimr_settings_card(
            "layer-group", "Lines", "Where each line's losses come from.",
            div(class = "sim-section-label", "Source"),
            netsimr_pill_radio("line_source", "Source", c("Frequency and severity" = "model", "Upload simulated losses" = "upload"), "model"),
            conditionalPanel(
              condition = "input.line_source == 'model'",
              numericInput("n_lines", "Number of lines", value = 3, min = 2, max = pfo_max_lines, step = 1),
              netsimr_help("Each line's claims are simulated with simulate_claims(): a claim count and a claim size for each",
                       "claim, every year.")
            ),
            conditionalPanel(
              condition = "input.line_source == 'upload'",
              fileInput("upload_file", "File", accept = netsimr_data_accept, placeholder = "No file selected"),
              netsimr_private_note(),
              netsimr_file_options("upload_header", "upload_sep", "upload_dec"),
              selectizeInput("upload_columns", "A column per line", choices = NULL, multiple = TRUE,
                             options = list(placeholder = "Upload a data file first")),
              netsimr_help("A row per simulated year and a column per line, such as the simulations downloaded from the",
                       "claims simulator. The copula reorders each column, so each line keeps its own distribution.")
            )
          ),
          netsimr_settings_card(
            "floppy-disk", "Settings file", "Keep this session's choices and restore them later.",
            downloadButton("save_settings", "Save settings", class = "btn-outline-pfo"),
            fileInput("load_settings", "Load settings", accept = ".txt", placeholder = "No file selected"),
            netsimr_help("The file keeps the lines, the dependence and the simulation settings. An uploaded file is not",
                     "kept: upload it again, and its columns are chosen as they were.")
          )
        ),
        uiOutput("lines_stats"),
        conditionalPanel(
          condition = "input.line_source == 'model'",
          bslib::card(
            netsimr_card_header("list-check", "By line", "Each line's name, claim count and claim size distributions."),
            bslib::card_body(uiOutput("line_inputs"))
          )
        ),
        bslib::card(
          netsimr_card_header("table-cells", "Expected losses", "Each line's expected annual claims and losses."),
          bslib::card_body(uiOutput("lines_table"))
        )
      )
    ),

    # ------------------------------------------------------------- Dependence
    bslib::nav_panel(
      title = "Dependence",
      value = "dependence",
      icon = icon("link"),

      netsimr_page_intro("Dependence", "How the lines' bad years come together."),

      netsimr_layout(
        netsimr_settings_card(
          "link", "Copula", "The dependence between the lines' ranks.",
          div(class = "sim-section-label", "Copula"),
          netsimr_pill_radio("copula", "Copula", c("Gaussian" = "gaussian", "t" = "t"), "gaussian"),
          conditionalPanel(
            condition = "input.copula == 't'",
            numericInput("copula_df", "Degrees of freedom", value = 4, min = 1, step = 1),
            netsimr_help("The fewer the degrees of freedom, the more often the lines have their worst years together.")
          ),
          tags$hr(class = "sim-divider"),
          div(class = "sim-section-label", "Correlations"),
          netsimr_pill_radio("corr_mode", "Correlations", c("One for every pair" = "all", "A matrix" = "matrix"), "all"),
          conditionalPanel(
            condition = "input.corr_mode == 'all'",
            numericInput("corr_all", "Correlation", value = 0.25, min = -0.99, max = 0.99, step = 0.05)
          ),
          netsimr_help("The correlations of the copula's normal draws: their ranks' correlation is a little lower, about",
                   "6 / pi times asin(r / 2)."),
          netsimr_help("A correlation of 0.25 between two lines is common for lines hit by the same economy or weather.")
        ),
        uiOutput("dependence_stats"),
        conditionalPanel(
          condition = "input.corr_mode == 'matrix'",
          bslib::card(
            netsimr_card_header("table-cells", "Correlation matrix", "Each pair's correlation, above the diagonal."),
            bslib::card_body(uiOutput("corr_inputs"))
          )
        ),
        bslib::card(
          netsimr_card_header("circle-info", "How the lines are joined"),
          bslib::card_body(
            p(class = "mb-2",
              "Each line is simulated on its own. The copula then draws, for every simulated year, a rank for each line,",
              "and each line's losses are put in that order: so each line keeps exactly its own distribution, and the",
              "ranks of the lines follow the copula (the reordering of Iman and Conover)."),
            p(class = "mb-0",
              "With a Gaussian copula, extreme years of two lines rarely coincide; a t copula, with the same correlation,",
              "makes them more likely, and leaves less diversification at the 99.5% level.")
          )
        )
      )
    ),

    # ---------------------------------------------------------------- Capital
    bslib::nav_panel(
      title = "Capital",
      value = "capital",
      icon = icon("scale-balanced"),

      netsimr_page_intro("Capital", "The portfolio's value at risk, its diversification and each line's capital."),

      netsimr_layout(
        netsimr_settings_card(
          "sliders", "Simulation", "The run and the level of the capital.",
          netsimr_amount_input("n_sims", "Number of simulations", value = 20000, min = 1000, max = 1e6),
          selectInput("level", "Level", choices = pfo_levels, selected = "0.995", selectize = FALSE),
          numericInput("seed", "Seed (optional)", value = 1, min = 0, step = 1),
          actionButton("run", "Run", icon = icon("play"), class = "btn-run"),
          netsimr_help("With uploaded losses, the number of simulations is the file's rows. At least 10,000 simulations",
                   "are recommended for figures at 99.5%.")
        ),
        uiOutput("capital_stats"),
        bslib::card(
          netsimr_card_header("table-cells", "By line", "Each line's and the total's mean, VaR, TVaR and capital."),
          bslib::card_body(
            uiOutput("capital_table"),
            div(class = "pfo-downloads",
                downloadButton("download_summary", "Summary (CSV)", class = "btn-outline-pfo"),
                downloadButton("download_losses", "Simulated losses (CSV)", class = "btn-outline-pfo"),
                downloadButton("download_report", "Report (HTML)", class = "btn-outline-pfo"),
                netsimr_excel_button("download_excel", class = "btn-outline-pfo"))
          )
        ),
        netsimr_result_tabs(
          id = "capital_tabs",
          bslib::nav_panel("Capital by line", netsimr_plot_output("capital_plot")),
          bslib::nav_panel("Total losses", netsimr_plot_output("total_plot")),
          bslib::nav_panel("Dependence",
                           div(class = "param-grid-2 mt-2",
                               selectInput("rank_x", "Line across", choices = NULL, selectize = FALSE),
                               selectInput("rank_y", "Line up", choices = NULL, selectize = FALSE)),
                           netsimr_plot_output("rank_plot", height = "480px"),
                           p(class = "dft-table-note",
                             "Each point is a simulated year, at the ranks of the two lines' losses. The square at the top",
                             "right holds the years in the worst 5% of both."))
        )
      )
    ),

    # -------------------------------------------------------- Standard formula
    bslib::nav_panel(
      title = "Standard formula",
      value = "standard",
      icon = icon("building-columns"),

      netsimr_page_intro("Solvency II standard formula",
                     "The capital for non-life premium and reserve risk, from each segment's volumes."),

      netsimr_layout(
        netsimr_settings_card(
          "circle-info", "How it works", "Articles 115 to 117 of Delegated Regulation (EU) 2015/35.",
          p(class = "mb-2",
            "Each segment's premium and reserve risk are combined with a correlation of 50%, its standard deviations",
            "those of Annex II (as amended in 2019). The segments are joined with the correlations of Annex IV, and the",
            "capital is three times the standard deviation times the volume."),
          netsimr_help("The premium volume is the larger of next year's and last year's earned premium, plus the premiums of",
                   "existing and future contracts beyond next year; the reserve volume is the best estimate of the claims",
                   "provision. Both net of reinsurance."),
          netsimr_help("The 80% adjustment for non-proportional reinsurance applies to segments 1, 4 and 5 where the",
                   "reinsurance qualifies. Geographical diversification is 1 for business in one region.")
        ),
        uiOutput("sf_stats"),
        bslib::card(
          netsimr_card_header("list-check", "Volumes by segment", "The segments written, with their premium and reserve volumes."),
          bslib::card_body(uiOutput("sf_inputs"))
        ),
        bslib::card(
          netsimr_card_header("table-cells", "Capital by segment", "Each segment on its own, and the total after diversification."),
          bslib::card_body(uiOutput("sf_table"),
                           div(class = "pfo-downloads", downloadButton("download_sf", "Standard formula (CSV)", class = "btn-outline-pfo")))
        ),
        netsimr_result_tabs(
          id = "sf_tabs",
          bslib::nav_panel("Capital by segment", netsimr_plot_output("sf_plot"))
        )
      )
    ),

    bslib::nav_spacer(),
    bslib::nav_item(netsimr_theme_switch())
  )
}
